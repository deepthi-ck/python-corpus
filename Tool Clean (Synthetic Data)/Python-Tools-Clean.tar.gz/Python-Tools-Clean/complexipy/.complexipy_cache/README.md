# complexipy cache directory #

This directory contains data from complexipy's cache, which stores previous
complexity results so future runs can compare per-function complexity changes.

**Do not** commit this to version control.
