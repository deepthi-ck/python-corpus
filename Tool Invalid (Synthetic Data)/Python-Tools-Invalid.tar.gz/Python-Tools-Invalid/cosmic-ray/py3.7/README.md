# cosmic-ray

**py3.7 boundary variant -- code-only.** No Python 3.7 interpreter exists
in the available build environments. This source is verified, not
asserted: `ast.parse(..., feature_version=(3, 7))` passes, and this
folder's own pytest suite runs unmodified and green under an available
interpreter. It was not run against the real tool.

No mechanical downgrade was needed for this folder: the source uses no
builtin generic subscripting, no `dataclasses`, and no
`from __future__ import annotations` -- nothing in it has a floor above
Python 3.6, so it is byte-for-byte identical to the py3.11/py3.13/py3.14
source.

Synthetic, deliberately-wrong Python project for **cosmic-ray**.

Domain: letter-grade banding, curving and roster statistics.

## What a wrong result would look like

Every test checks only one branch with a loose assertion. On every
live-measured version (py3.11/py3.13/py3.14, identical source) this comes
out to a real cosmic-ray survival rate of **~85% surviving mutants** --
well past the 50%-survival target. There is no reason to expect a
different number on 3.7 since nothing in the source or tests is
version-dependent.

## Command (not run here)

```bash
cosmic-ray init cosmic-ray.toml session.sqlite
cosmic-ray exec cosmic-ray.toml session.sqlite
cr-report session.sqlite
```

## Layout

```text
gradeband/
  pyproject.toml
  cosmic-ray.toml
  src/gradeband/
    __init__.py
    bands.py
    curve.py
    stats.py
  tests/
    test_gradeband.py
```
